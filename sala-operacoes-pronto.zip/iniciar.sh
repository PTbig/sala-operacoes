#!/bin/sh
echo "========================================================"
echo "  SALA DE OPERAÇÕES - GESTÃO DE OCORRÊNCIAS E MEIOS"
echo "========================================================"
echo ""

if command -v node >/dev/null 2>&1; then
    echo "A iniciar com Node.js local..."
    echo "Aceder em: http://localhost:8080"
    node --disable-warning=ExperimentalWarning server.js
elif command -v docker >/dev/null 2>&1; then
    echo "Node.js não encontrado. A iniciar via Docker..."
    docker compose up -d --build
    echo "Aplicação em execução via Docker!"
else
    echo "Erro: Nem Node.js nem Docker foram encontrados."
    exit 1
fi
