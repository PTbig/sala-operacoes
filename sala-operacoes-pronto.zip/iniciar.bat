@echo off
chcp 65001 > nul
title Sala de Operações - Bombeiros
echo ========================================================
echo   SALA DE OPERAÇÕES - GESTÃO DE OCORRÊNCIAS E MEIOS
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] O Node.js não foi encontrado no sistema.
    echo.
    echo Para correr no Windows:
    echo 1. Instale o Node.js 22 (https://nodejs.org)
    echo 2. Ou execute via Docker: docker compose up -d --build
    echo.
    pause
    exit /b 1
)

echo A iniciar servidor...
echo Aceder em: http://localhost:8080
echo Utilizador inicial: central
echo Palavra-passe temporária: centraladmin
echo.
node --disable-warning=ExperimentalWarning server.js
pause
